package com.example.restarttechtask.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.material.Surface
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.restarttechtask.widgets.TabLayout

@Composable
fun MainQuestionsScreen(modifier: Modifier = Modifier) {
    val list = listOf<Int>(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20)
    val tabTitles = listOf("Writing1", "Oral")
    val tabIcons = listOf(Icons.Default.Edit, Icons.Rounded.Phone)
    val index = remember { mutableStateOf(0) }

    Surface(modifier) {
        Column {
            TabLayout(tabTitles, tabIcons) {
                index.value = it

            }
            when (index.value) {
                0 -> WritingQuestionScreen()
                1 -> OralQuestionsScreen()
            }
        }

    }
}